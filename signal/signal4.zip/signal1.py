import librosa
import numpy as np
import soundfile as sf
from numpy.fft import fft, ifft

input_file = 'bayrakfm.wav'


y, sample_rate = librosa.load(input_file, sr=None)

frame_size = sample_rate
num_frames = len(y) // frame_size
modified_signal = np.array([])

for i in range(num_frames):
    start = i * frame_size
    end = start + frame_size
    frame = y[start:end]

    frame_transformed = fft(frame) #fourier transform

    #second half replaced with first half
    half_index = len(frame_transformed) // 2
    frame_transformed = np.concatenate((frame_transformed[half_index:], frame_transformed[:half_index]))

    #inverse fourier transform
    modified_frame = ifft(frame_transformed).real
    modified_signal = np.concatenate((modified_signal, modified_frame))

hidden_output_file = 'hidden_message.wav'
sf.write(hidden_output_file, modified_signal, sample_rate)
print("Part 1 answer: Hidden message saved as hidden_message.wav:", hidden_output_file) #final signal for part1
 