import numpy as np
import soundfile as sf

# H(z)
b = [1, -7/4, -1/2]  
a = [1, 1/4, -1/8]   

def custom_filter(b, a, signal):
    output = np.zeros_like(signal)
    N = len(signal)
    
    for n in range(N):
        for i in range(len(b)):
            if n - i >= 0:
                output[n] += b[i] * signal[n - i]

        for j in range(1, len(a)):
            if n - j >= 0:
                output[n] -= a[j] * output[n - j]

    return output

y, sample_rate = sf.read('hidden_message.wav') #uploading the first question's output signal

filtered_signal = custom_filter(b, a, y) #filter

filtered_output_file = 'filtered_hidden_message.wav'
sf.write(filtered_output_file, filtered_signal, sample_rate)
print("Part 2 answer: Filtered hidden message saved as:", filtered_output_file) #final signal for part2
