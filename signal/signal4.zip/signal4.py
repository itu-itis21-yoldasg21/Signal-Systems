import numpy as np
import matplotlib.pyplot as plt

def H1(w):
    num = 10 * (1 + 1j*w)
    den = (1 + 1j*w/10)**2
    return num / den

def H2(w):
    return 1 / (1 + 1j*w/10)

w = np.logspace(-1, 3, 500)

def plt_bode(w, mag, phase, title):
    plt.figure(figsize=(8, 6))
    
    plt.subplot(2, 1, 1)
    plt.semilogx(w, mag)
    plt.title('Bode Magnitude Plot for ' + title)
    plt.ylabel('Magnitude (dB)')
    
    plt.subplot(2, 1, 2)
    plt.semilogx(w, phase)
    plt.title('Bode Phase Plot for ' + title)
    plt.xlabel('Frequency (rad/s)')
    plt.ylabel('Phase (degrees)')
    
    plt.tight_layout()
    plt.show()

H1_mag = 20 * np.log10(np.abs(H1(w))) 
H1_phase = np.unwrap(np.angle(H1(w), deg=True))  


H2_mag = 20 * np.log10(np.abs(H2(w)))  
H2_phase = np.unwrap(np.angle(H2(w), deg=True)) 


H_cascade = H1(w) * H2(w)
cascade_mag = 20 * np.log10(np.abs(H_cascade))  
cascade_phase = np.unwrap(np.angle(H_cascade, deg=True)) 


plt_bode(w, H1_mag, H1_phase, 'H1(jω)')
plt_bode(w, H2_mag, H2_phase, 'H2(s)')
plt_bode(w, cascade_mag, cascade_phase, 'Cascade of H1 and H2')
